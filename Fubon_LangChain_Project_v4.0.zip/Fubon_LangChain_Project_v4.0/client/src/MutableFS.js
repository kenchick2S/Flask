import React, { useCallback, useState, useEffect } from 'react';
import axios from 'axios';

import { fileMap, defineFileAction, ChonkyIconName, FullFileBrowser, setChonkyDefaults, ChonkyActions} from 'chonky';
import { ChonkyIconFA } from 'chonky-icon-fontawesome';
import './MutableFS.css'

setChonkyDefaults({ iconComponent: ChonkyIconFA });

const StoryComponent = () => {
    // Story controls
    const [path, setPath] = useState("/");
    const [file, setFile] = useState([])

    const { data, methods, fileActionHandler } = fileMap.useFileMap({
        baseFileMap: {"qwerty123456":{"id":"qwerty123456","name": "loading...", "isDir":true,"childrenIds":[]}},
        initialFolderId: "qwerty123456"
    });

    const get_folders = (path) => {

        axios.post('http://127.0.0.1:5001/check_folder', {'subpath': path})
        .then((response) => {
            console.log(response.data);
            let temp_file_map = response.data['content']['fileMap'];
            for(const key in temp_file_map){
                if(temp_file_map[key].hasOwnProperty('isDir')){
                    temp_file_map[key]['isDir'] = true;
                }
            }
            methods.setFileMap(response.data['content']['fileMap']);
            if(path === '/'){
                methods.setCurrentFolderId(response.data['content']['rootFolderId']);
            }
        })
        .catch(() => {
            // alert("無此資料夾或檔案");
        });
    } 

    const new_folders = () => {

        var inputValue = window.prompt('請輸入資料夾名稱', '新增資料夾');
        if (inputValue != null || "") {
            axios.post('http://127.0.0.1:5001/new_folder', {'folderName': inputValue, 'subpath': path})
            .then((response) => {
                console.log(response.data);
                get_folders(path);
            })
            .catch((error) => {
                console.error(error);
            }); 
        }
    };

    const delete_files = (state) => {
        axios.post('http://127.0.0.1:5001/delete_metadata', {'selected': state})
        .then((response) => {
            get_folders(path);
            alert(response.data.result);
        })
        .catch(() => {
            alert("無此資料夾或檔案");
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        if(file.length !== 0){
            console.log("submit");
            const formData = new FormData(e.target);
            for (let i = 0; i < file.length; i++) {
                formData.append('file', file[i]);
            }

            formData.append('subpath', path)
    
            axios.post('http://127.0.0.1:5001/upload_metadata', formData)
            .then((response) => {
                get_folders(path);
                alert(response.data.result)
            })
            .catch((error) => {
                alert(error);
            });
        }
      };
    
    useEffect( () => {
        console.log(path);
        get_folders(path);
    }, [path]);

    useEffect( () => {
        console.log(file);
        if(file.length !== 0){
            document.getElementById("UploadBtn").click();
        }
    }, [file]);

    const customActionHandler = useCallback(
        data => {
            console.log(`File action [${data.id}]`, data);
            switch(data.id) {
                case ChonkyActions.OpenFiles.id:{
                    if(data.payload.targetFile.hasOwnProperty('path') && data.payload.targetFile.hasOwnProperty('isDir')){
                        setPath(data.payload.targetFile.path);
                    }
                    break;
                }
                case CreateFolder.id: {
                    new_folders();
                    break;
                }
                case DeleteFiles.id: {
                    // 看 data payload 有哪些 selections
                    let check = window.confirm("確定要刪除嗎?");
                    if(check){
                        delete_files(data.state.selectedFilesForAction);
                    }
                    break;
                }
                case UploadFiles.id: {
                    document.getElementById("fileUpload").click();
                    console.log(file);
                    break;
                }
            }
            fileActionHandler(data);
        },
        [fileActionHandler]
    );

    const CreateFolder = defineFileAction({
        id: 'create_folder',
        button: {
            name: '新增資料夾',
            toolbar: true,
            tooltip: 'Create a folder',
            icon: ChonkyIconName.folderCreate,
        },
    });

    const UploadFiles = defineFileAction({
        id: 'upload_files',
        button: {
            name: '上傳檔案',
            toolbar: true,
            tooltip: 'Upload files',
            icon: ChonkyIconName.upload,
        },
    });

    const DeleteFiles = defineFileAction({
        id: 'delete_files',
        requiresSelection: true,
        hotkeys: ['delete'],
        button: {
            name: '刪除檔案',
            toolbar: true,
            contextMenu: true,
            group: 'Actions',
            icon: ChonkyIconName.trash,
        },
    });

    return (
        <>
            <div className="chonky-wrapper">
                <FullFileBrowser
                    folderChain={data.folderChain}
                    files={data.files}
                    onFileAction={customActionHandler}
                    fileActions={[
                        ChonkyActions.OpenFiles,
                        CreateFolder,
                        UploadFiles,
                        DeleteFiles,
                    ]}
                    disableDragAndDrop={true}
                />
            </div>
            <form id="UploadForm" encType="multipart/form-data" style={{"display": "none"}} onSubmit={handleSubmit} >         
                <input type="file" id="fileUpload" multiple onChange={(e) => setFile(e.target.files)}/>
                <button id="UploadBtn" type="submit"></button>
            </form>
        </>
    );
};

StoryComponent.displayName = 'Mutable FS';
export const MutableFS = StoryComponent;