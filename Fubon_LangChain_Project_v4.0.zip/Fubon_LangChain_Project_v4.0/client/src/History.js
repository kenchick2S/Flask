import { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { CancelSVG, HistorySVG } from './SVG';
import { HistoryContext } from './Context';

import './History.css'

export default function History() {

    const context = useContext(HistoryContext);
    const [rowsData, setRowsData] = useState([]);

    const convertDateString = (dateString) => {
        // 將時間字串中的"下午"轉換為24小時制
        let [datePart, timePart] = dateString.split(' ');
        let [year, month, day] = datePart.split('/');
    
        // 將時間轉換為24小時制
        let [hours, minutes, seconds] = timePart.split(':');

        if (hours.includes('下午')) {
            hours = hours.replace('下午', '');
            if(hours !== '12') hours = String(Number(hours) + 12);
        } else if (hours.includes('上午')) {
            hours = hours.replace('上午', '');
            if(hours === '12') hours = '00';
        }
    
        // 格式化為 ISO 字串
        return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}T${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}:${seconds.padStart(2, '0')}`;
    }

    const checkDate = (dateString) => {

        console.log(convertDateString(dateString))

        const inputDate = new Date(convertDateString(dateString));
        const today = new Date();
        const yesterday = new Date();
        
        // 將時間設置為 00:00:00，方便比較
        today.setHours(0, 0, 0, 0);
        yesterday.setHours(0, 0, 0, 0);
        yesterday.setDate(today.getDate() - 1);
        
        if (inputDate >= today && inputDate < today.getTime() + 86400000) {
            // 今天
            return dateString.split(' ')[1]; // 回傳 時分秒
        } else if (inputDate >= yesterday && inputDate < today) {
            // 昨天
            return 'yesterday';
        } else {
            const daysDiff = Math.floor((today - inputDate) / 86400000)+1;
            if(daysDiff > 365)
                return `${parseInt(daysDiff/365)} years ago`;
            else if(daysDiff > 30)
                return `${parseInt(daysDiff/30)} months ago`;
            else
                return `${daysDiff} days ago`;
        }
    }

    const handleListHistory = () => {
        let rows = []

        axios('http://localhost:5001/get_history_list')
        .then((response) => {
            // console.log(response.data['history_list']);
            for (let history of response.data['history_list']) {
                rows.push(
                <div role='button' className='history-row' chatId={history["chat_id"]} onClick={handleGetHistory}>
                    <div className='history-text'>{history["chat_title"]}</div>
                    <div className='history-time'>{checkDate(history["chat_time"])}</div>
                </div>);
            }
            setRowsData(rows);
        })
        .catch((error) => console.log(error))


    }

    const handleGetHistory = async(e) => {

        const response = await axios.get( `http://localhost:5001/history?id=${e.target.getAttribute('chatId')}`);

        context.message_setter(response.data.chat);
        context.chatId_setter(parseInt(e.target.getAttribute('chatId'), 10));
        context.check_setter(false);
        context.show_setter(false);
    }

    useEffect(() => {

        if(context.show_state){
            handleListHistory();
        }

    },[context.show_state])

    return(
        <>
            <div className='history-container'>
                <div role='button' className='history-close-btn' onClick={() => {context.show_setter(false)}}> 
                    <CancelSVG/> 
                </div>
                <div className='history-list'>
                    {rowsData}
                </div>
            </div>
        </>
    )

}