
import { useState } from 'react';
import axios from 'axios';

import './ConnectSettingPage.css'

function ConnectSettingPage(){

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        axios.post('http://127.0.0.1:5001/save_db_config', data)
        .then(response => {

            console.log('成功:', response.data);

        })
        .catch(error => {

            console.error('錯誤:', error);
        });
    
    }

    const handleTest = () => {

        axios('http://127.0.0.1:5001/test_db_connection')
        .then(response => {

            alert(response.data.result);

        })
        .catch(error => {

            // console.error('錯誤:', error);
            alert(error);
        });
    
    }

    return(
        <>
            <div className="setting-container">
                <h3>連線參數設定</h3>
                <form className="form-container" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="driver">資料庫類型:</label>
                        <select id="driver" name="driver">
                            <option value="Oracle">Oracle</option>
                            <option value="MSSQL">MSSQL</option>
                        </select>
                    </div>
                    <div className="setting-form">
                        <div>
                            <label for="server">伺服器名稱:</label>
                            <input type="text" id="server" name="server" placeholder='ex: 192.168.1.1' required />
                        </div>
                        <div>
                            <label for="port">連線埠 (Port):</label>
                            <input type="text" id="port" name="port" placeholder='ex: 1433' />
                        </div>
                        <div>
                            <label for="database">資料庫名稱:</label>
                            <input type="text" id="database" name="database" required />
                        </div>
                        <div>
                            <label for="username">使用者名稱:</label>
                            <input type="text" id="username" name="username" required />
                        </div>
                        <div>
                            <label for="password">密碼:</label>
                            <input type="password" id="password" name="password" required />
                        </div>
                    </div>
                    <div style={{marginLeft: 'auto', marginRight: 'auto', width: 'fit-content'}}>
                        <button type="submit" >儲存</button>
                        <button type="button" onClick={handleTest}>測試連線</button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default ConnectSettingPage;