import sqlite3
import csv

conn = sqlite3.connect("langflow.db")

cursor = conn.cursor()

cursor.execute("SELECT * FROM user")

rows = cursor.fetchall()

with open("user.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerows(rows)

conn.close()