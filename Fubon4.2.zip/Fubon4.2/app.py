from flask import Flask, request, render_template, make_response, jsonify, send_file
from flask_cors import CORS, cross_origin
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import timedelta

from getCustomerDataset import  getCsvDataset
import time
import os
import shutil
import tempfile
import pandas as pd
import json

import io
from urllib.parse import quote

import uuid
import hashlib

import pyodbc

from Langchain_Agent import LangchainAgent
from Speech_Agent import transcribe


# Global Variables: 儲存資料來渲染表格
Ai_response = ""
Agent = LangchainAgent()

root = "./database"

# Flask App
app = Flask(__name__)

app.config['JWT_SECRET_KEY'] = 'your_secret_key'  # 更改為你的密鑰
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=1)
jwt = JWTManager(app)

app.config['JSON_SORT_KEYS'] = False
CORS(app)

# Function

def list_directory_contents(root_path = root, path_postfix="/"):
    try:
        path = root_path + path_postfix
        items = os.listdir(path)
        
        parent_folder_id = create_uuid_from_string(path)

        for item in items:
            item_path = os.path.join(path, item)

            item_id = create_uuid_from_string(str(item_path))

            if(item_id not in all_item_json["fileMap"][parent_folder_id]["childrenIds"]):
                all_item_json["fileMap"][parent_folder_id]["childrenIds"].append(item_id)

            if os.path.isfile(item_path): # file

                all_item_json["fileMap"][item_id] = {"id":item_id, "name": item, "parentId": parent_folder_id, "path": item_path.replace(root_path, '')}
            
            elif os.path.isdir(item_path): # folder

                all_item_json["fileMap"][item_id] = {"id":item_id, "name": item,"isDir": "true","childrenIds":[], "parentId": parent_folder_id, "path": item_path.replace(root_path, '')}
                

        return all_item_json

    except FileNotFoundError:
        print(f"The directory {path} does not exist.")
    except PermissionError:
        print(f"Permission denied for directory {path}.")
    except Exception as e:
        print(f"An error occurred: {e}")

    return None

def create_uuid_from_string(val: str):
    hex_string = hashlib.md5(val.encode("UTF-8")).hexdigest()
    return str(uuid.UUID(hex=hex_string))

rootFolderId = create_uuid_from_string(root + '/')
all_item_json = {"rootFolderId": rootFolderId,"fileMap":{rootFolderId:{"id":rootFolderId,"name":"database","isDir": "true","childrenIds":[], "path": "/"}}}

# Backend API

# 測試用
@app.route('/get_test', methods=['POST', 'OPTIONS'])
@cross_origin()
def test_input():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    sqlCommand = '''
        SELECT DISTINCT CN002, SUM(TA006) AS 總交易金額 FROM 客戶資料表 JOIN 交易資料表 ON CUS001 = CI004 WHERE YEAR(TD002) = 2023 AND AD003 LIKE '%台中市%' GROUP BY CN002
    '''
    Agent.SummaryFunc.sqlCommand = sqlCommand
    Agent.SummaryFunc.selected_driver = 'Oracle'
    Agent.SummaryFunc.selected_database = 'TestDB'
    result = Agent.SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./database/Oracle", sqlCommand, auth_tables=["交易資料表", "客戶資料表", "員工資料表"]))

    return make_response(jsonify({'response': "查詢成功", 'data': result.to_json(orient='records')}), 200, header)

@app.route('/get_keyword_test', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_keyword_test():

    global Ai_response

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    result = '測試'

    data = request.get_json()
    Agent.SummaryFunc.Input_Question = data.get('inputText')

    return make_response(jsonify({'response': result, 'check': 'True'}), 200, header)

@app.route('/get_summary_test', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_summary_test():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    try:
        data = request.get_json()
        user_input = data.get('inputText')
        Agent.SummaryFunc.Input_Question = user_input
        with open(Agent.SummaryFunc.test_folder + Agent.SummaryFunc.test_jsonfile, 'r') as f:
            data = json.load(f)
            if user_input in data.keys():
                temp = pd.read_csv(Agent.SummaryFunc.test_folder + data[user_input], encoding='utf-8')
                Agent.SummaryFunc.store_dataset(temp, True)

                start = time.time()
                result = Agent.SummaryFunc.summary()
                end = time.time()

                print(f"\nTotal Summary time: {end - start}")
            else:
                result = "沒有這個查詢結果"

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'response': result}), 200, header)

# 查看指定資料夾底下的所有檔案

@app.route('/check_folder', methods=['POST', 'OPTIONS'])
@cross_origin()
def check_folder():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    data = request.get_json()
    subpath = data.get('subpath')
    result = list_directory_contents(path_postfix=subpath)
    if result is not None:
        return make_response(jsonify({"content": result}), 200, header)

    return make_response(jsonify({"content": []}), 404, header)

@app.route('/new_folder', methods=['POST', 'OPTIONS'])
@cross_origin()
def new_folder():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    
    try:
        result = "新增成功"
        data = request.get_json()
        folder_name = data.get('folderName')
        subpath = data.get('subpath')
        folder_path = os.path.join(root + subpath, folder_name)
        os.mkdir(folder_path)
        print(f"Directory '{folder_path}' created successfully.")
    except FileExistsError:
        print(f"Directory '{folder_path }' already exists.")
        result = "資料夾已存在"
    except OSError as e:
        print(f"Error creating directory '{folder_path }': {e}")
        result = "無法新增"

    return make_response(jsonify({'status': result}), 200, header)

# 上傳檔案到所在資料夾
@app.route('/upload_metadata', methods=['POST'])
@cross_origin()
def upload_metadata():
    messages = ""
    print(f'\nfile objects that I receive in this upload:{request.files}')
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in the request.'}), 400

    files = request.files.getlist('file')  # Get the list of files
    subpath = request.form.get('subpath')

    for file in files:
        print('\nthis file:', file)
        if file.filename == '':
            messages +=  "檔案不存在\n"
        
        try:
            saved_file_name = os.path.join(root + subpath, file.filename)

            if os.path.isfile(saved_file_name):
                messages += f'{file.filename} 檔案已存在\n'

            else:    
                file.save(saved_file_name)
                messages += f'{file.filename} 上傳成功\n'
            
        except Exception as e:
            app.logger.debug('Debug message')
            print(str(e))
            messages += f'{file.filename} 上傳失敗\n'

    return jsonify({'result': messages}), 200

# 刪除資料
@app.route('/delete_metadata', methods=['POST'])
@cross_origin()
def delete_metadata():

    result = ""
    data = request.get_json()
    selected_list = data.get('selected')
    for item in selected_list:
        try:
            if('isDir' in item):
                os.rmdir(root + item['path'])
            else:
                os.remove(root + item['path'])
            
            item_id = create_uuid_from_string(root + item['path'])
            parentId = all_item_json["fileMap"][item_id]['parentId']
            all_item_json["fileMap"][parentId]['childrenIds'].remove(item_id)
            del all_item_json["fileMap"][item_id]

            result += (f"{item['name']}: 刪除成功\n")

        except Exception as e:
            print(f"Error: {e}")
            if('isDir' in item):
                result += (f"{item['name']}: 資料夾必須為空\n")
            else:
                result += (f"{item['name']}: 刪除失敗\n")
    return jsonify({'result': result}), 200

@app.route('/upload_speech', methods=['POST'])
@cross_origin()
def upload_speech():
    messages = ""
    print(f'\nfile objects that I receive in this upload:{request.files}')
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in the request.'}), 400

    files = request.files.getlist('file')  # Get the list of files

    for file in files:
        print('\nthis file:', file)
        if file.filename == '':
            messages +=  "檔案不存在\n"
        
        try:
            messages = transcribe(file)
            print(messages)
            
        except Exception as e:
            app.logger.debug('Debug message')
            print(str(e))
            messages += f'{file.filename} 上傳失敗\n'

    return jsonify({'result': messages}), 200

# SQL
@app.route('/get_keyword', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_keyword():

    global Ai_response

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    user_input = data.get('inputText') #等同於 data['inputText']
    user_token = data.get('token')
    chatId = data.get('chatId')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
        tokens = json.load(f)

    if user_token in tokens:
    
        try:
            with open(f'./user_data/{tokens[user_token]}/chat.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if len(data["q_history"][int(chatId)]) >= 30:

                result = "請新增聊天" 
            
            else:
                start = time.time()
                result = Agent.parse_question(user_input).replace("A.", "")
                end = time.time()

                print(f"\nTotal Query time: {end - start}")
            
            return make_response(jsonify({'response': result}), 200, header)

        except Exception as e:
            result = "我不知道怎麼回答"
            print(f'\n錯誤訊息: {e}')
    
    else:
        result = "請登入"
        
    
    return make_response(jsonify({'response': result}), 200, header)
    

@app.route("/get_query", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_query():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']
    user_token = data.get('token')
    user_keyword = data.get('keyword')
    chatId = data.get('chatId')
    username = data.get('username')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
        tokens = json.load(f)

    sql = ''
    selected_driver = ''
    selected_database = ''
    dataset = []
    question = ''

    if user_token in tokens:

        try:
            with open('./user_database/users_auth.json', 'r', encoding='utf-8') as f:
                users_auth = json.load(f)

            Ai_response = Agent.query_by_SQL(auth_tables = users_auth[tokens[user_token]]["databases"].split(','), username = username, chatId = int(chatId), question = user_input, keyword = user_keyword)
            
            result = "查詢成功"
            question = Ai_response['question']
            sql = Ai_response['sqlCommand']
            selected_driver = Ai_response['selected_driver']
            selected_database = Ai_response['selected_database']

            df = Ai_response['dataset'].copy(deep=True)
            for column in df.dtypes[df.dtypes == 'datetime64[ns]'].index:
                df[column] = df[column].apply(lambda x: x.strftime("%Y-%m-%d"))

            json_data = df.to_json(orient='records')
            parsed = json.loads(json_data)

        except Exception as e:
            result = f"無法查詢，以下是系統生成的SQL：\n{Ai_response['sqlCommand']}\n資料庫來源：{Ai_response['selected_driver']}"
            print(f'\n錯誤訊息: {e}')
        
    else:
        result = "請登入"
    
    return make_response(jsonify({'response': result, 'question': question, 'sql': sql, 'selected_db': [selected_driver, selected_database], 'dataset': json_data}), 200, header)


@app.route("/get_keyword_and_query", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_keyword_and_query():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']
    user_token = data.get('token')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
        tokens = json.load(f)

    Agent.SummaryFunc.Input_Question = user_input

    try:
        Ai_keyword = ""
        Ai_keyword = Agent_Executor.invoke({"input": user_input})['output'].replace("A.", "")

        print(Ai_keyword)

        if user_token in tokens:
            with open('./user_database/users_auth.json', 'r', encoding='utf-8') as f:
                users_auth = json.load(f)

            Ai_query = Agent.query_by_SQL(auth_tables = users_auth[tokens[user_token]]["databases"].split(','))

            if not isinstance(Ai_query, str):
                if (Ai_query is None or len(Ai_query) == 0):
                    result = '資料不存在'

                result = Agent.SummaryFunc.sqlCommand
            else:
                result = Ai_query
        else:
            result = "請登入"

        return make_response(jsonify({'keyword': Ai_keyword, 'query': result}), 200, header)

    except Exception as e:
        result = f"無法查詢，以下是系統生成的SQL：\n{Agent.SummaryFunc.sqlCommand}\n資料庫來源：{Agent.SummaryFunc.selected_driver}"
        print(f'\n錯誤訊息: {e}')
    
    return make_response(jsonify({'keyword': Ai_keyword, 'query': result}), 200, header)

@app.route("/get_direct_query", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_direct_query():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    # print(f'server receive data from User input: {data}')

    user_driver = data.get('driver')
    user_sql = data.get('sql-query')
    user_token = data.get('token')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
        tokens = json.load(f)

    if user_token in tokens:

        # if user_id < -1:
        #     user_id = -1

        # user_driver = Agent.SummaryFunc.database_history[user_id][0]

        directory = './database/'

        try:

            with open('./user_database/users_auth.json', 'r', encoding='utf-8') as f:
                users_auth = json.load(f)

            result = getCsvDataset.dataset_query_sql(directory + user_driver[0], user_sql, auth_tables = users_auth[tokens[user_token]]["databases"].split(','))

            if type(result) != str:
                for column in result.dtypes[result.dtypes == 'datetime64[ns]'].index:
                    result[column] = result[column].apply(lambda x: x.strftime("%Y-%m-%d"))

                json_data = result.to_json(orient='records')

                return make_response(jsonify({"result": "查詢成功", "data": json_data}), 200, header)

        except Exception as e:
            result = "查詢失敗"
            print(f'\n錯誤訊息: {e}')
    
    else:
        result = "請登入"

    return make_response(jsonify({'result': result, "data": ""}), 200, header)


# 表格資料回傳
@app.route("/result")
def result():

    data = request.get_json()

    data_id = data.get('id')
    chatId = data.get('chatId')
    username = data.get('username')

    if data_id < 0:
        data_id = -1

    try:
        header={
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST'
        }
        # if type(Agent.SummaryFunc.datasets[id]) == list:
            
        #     json_data = Agent.SummaryFunc.datasets[id]

        # elif Agent.SummaryFunc.datasets[id].empty:
        #     print(Agent.SummaryFunc.datasets[id])
        #     json_data = [{"無欄位名稱": "無欄位資料"}]

        # else:
        #     df = Agent.SummaryFunc.datasets[id].copy(deep=True)
        #     for column in df.dtypes[df.dtypes == 'datetime64[ns]'].index:
        #         df[column] = df[column].apply(lambda x: x.strftime("%Y-%m-%d"))

        #     json_data = df.to_json(orient='records')
        #     parsed = json.loads(json_data)

        with open(f'./user_data/{username}/chat.json', 'r', encoding='utf-8') as f:
            data = json.load(f)

        return make_response(jsonify([{"question":data[q_history][chatId][id], "data":[{"": ""}], "count": len(data['q_history'][chatId][id]), "sql": data['sql_history'][chatId][id], "driver": data['database_history'][chatId][id][0], "database": data['database_history'][chatId][id][1]}]), 200, header)

    except Exception as e:
        print(str(e)+"\n")
        return make_response(jsonify([{"question":"", "data":[{"": ""}], "count": 0, "sql": "", "driver": "", "database": []}]), 200, header)


@app.route("/download")
def download():
    id = int(request.args.get('id'))
    if id > len(Agent.SummaryFunc.datasets)-1:
         id = len(Agent.SummaryFunc.datasets)-1

    id_name = id+1
    
    if Agent.SummaryFunc.count > 5:
        id_name += (Agent.SummaryFunc.count-5)

        
    print(f"saved length: {len(Agent.SummaryFunc.datasets)}")
    print(f"id: {id}")
    
    header={
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET'
            }

    try:
        if Agent.SummaryFunc.datasets[id].empty:
            print(Agent.SummaryFunc.datasets[id])

            return make_response("無資料可下載", 404, header)

        else:
            header={
                'Content-Type': "text/csv",
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET',
                "Content-Disposition": "attachment; filename*=UTF-8''{utf_filename}".format(utf_filename=quote(f"第{id_name}個查詢結果.csv".encode('utf-8')))
            }

            df = Agent.SummaryFunc.datasets[id].copy(deep=True)
            for column in df.dtypes[df.dtypes == 'datetime64[ns]'].index:
                df[column] = df[column].apply(lambda x: x.strftime("%Y-%m-%d"))

            print("準備下載...")
            
            return make_response(df.to_csv(encoding='utf-8', index=False), 200, header)
            # buffer = io.BytesIO()
            # df.to_csv(buffer,encoding='utf-8')
            # buffer.seek(0)
            # return send_file(buffer,
            #      download_name="test.csv",
            #      mimetype='text/csv')

    except Exception as e:
        print(str(e)+"\n")
        return make_response("錯誤", 404, header)

# 聊天歷史紀錄
@app.route("/get_history_list", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_history_list():
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    user_token = data.get('token')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
        tokens = json.load(f)

    if user_token in tokens:

        try:

            with open(f'./user_data/{tokens[user_token]}/chat.json', 'r', encoding='utf-8') as f:
                data = json.load(f)

            return make_response(jsonify({'history_list': data["chat_history_list"][::-1]}), 200, header)
        
        except:

            return make_response(jsonify({'history_list': []}), 200, header)

@app.route("/history", methods=['POST', 'OPTIONS'])
@cross_origin()
def history():
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    user_token = data.get('token')
    chatId = data.get('chatId')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
        tokens = json.load(f)

    if user_token in tokens:

        try:

            with open(f'./user_data/{tokens[user_token]}/chat.json', 'r', encoding='utf-8') as f:
                data = json.load(f)

                # Agent.SummaryFunc.history = data['q_history'][chatId]
                # Agent.SummaryFunc.sql_history = data['sql_history'][chatId]
                # Agent.SummaryFunc.database_history = data['db_history'][chatId]
                # Agent.SummaryFunc.count = len(Agent.SummaryFunc.history)
                # Agent.SummaryFunc.datasets = [[{}] for _ in range(Agent.SummaryFunc.count)]

                # print(data['q_history'][chatId])
            return make_response(jsonify({'chat': data["chat"][int(chatId)], 'q_history': data["q_history"][int(chatId)], 'sql_history': data["sql_history"][int(chatId)], 'db_history': data["db_history"][int(chatId)]}), 200, header)
        
        except Exception as e:
            print(e)

            return make_response(jsonify({'chat': [], 'q_history': [], 'sql_history': [], 'db_history': []}), 200, header)

@app.route("/remove_history")
def remove_history():

        header={
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET'
        }

        Agent.SummaryFunc.history = []
        Agent.SummaryFunc.sql_history = []
        Agent.SummaryFunc.datasets = []
        Agent.SummaryFunc.database_history = []
        Agent.SummaryFunc.count = 0

        return make_response(jsonify({'result': "刪除成功"}), 200, header)

@app.route("/save_history", methods=['POST', 'OPTIONS'])
@cross_origin()
def save_history():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    chatId = None

    try:
        if request.method == 'POST':
            req = request.get_json()

            with open(f'./user_data/{req['username']}/chat.json', 'r', encoding='utf-8') as f:
                data = json.load(f)

                print(req['chat'])

                if int(req['chatId']) == -1:
                    data['chat'].append(req['chat'])
                    chatId = len(data['chat'])-1
                    data['chat_history_list'].append({
                        "chat_title": req['chat'][1]['HumanInput'],
                        "chat_time": req['chat'][1]['HumanTime'],
                        "chat_id": chatId
                    })

                    data['q_history'].append([])
                    data['sql_history'].append([])
                    data['db_history'].append([])
                    
                else:
                    chatId = int(req['chatId'])

                    data['chat'][chatId] = req['chat']


            with open(f'./user_data/{req['username']}/chat.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)

    except Exception as e:
        print(e)
        print("error!!!")
        chatId = -1
    
    return make_response(jsonify({'chatId': chatId}), 200, header)

@app.route("/save_config", methods=['POST', 'OPTIONS'])
@cross_origin()
def save_config():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    token = data.get('token')
    result = ""
    # print(f'server receive data from User input: {data}')

    try:

        with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
          tokens = json.load(f)

        print(token in tokens)

        if token in tokens:
            username = tokens[token]

            del data['token']

            with open(f'./config/{username}/config.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            
            result = "儲存成功"

    except Exception as e:
        result = "儲存失敗"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'result': result}), 200, header)

@app.route("/get_config", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_config():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    token = data.get('token')
    # print(f'server receive data from User input: {data}')

    try:
        with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
          tokens = json.load(f)

        print(token in tokens)

        if token in tokens:
            username = tokens[token]

            with open(f'./config/{username}/config.json', 'r', encoding='utf-8') as f:
                result = json.load(f)
            
            status = 200
        

    except Exception as e:
        result = "儲存失敗"
        status = 401
        print(f'\n錯誤訊息: {e}')
    
    return make_response(jsonify({'result': result}), status, header)

# 連線設定
@app.route("/save_db_config", methods=['POST', 'OPTIONS'])
@cross_origin()
def save_db_config():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')

    try:
        with open('./config/db_config.json', 'r', encoding='utf-8') as f:
            db_config = json.load(f)
            db_config[data['connection']] = data

        with open('./config/db_config.json', 'w', encoding='utf-8') as f:
            json.dump(db_config, f, ensure_ascii=False)
        result = "儲存成功"

    except Exception as e:
        result = "儲存失敗"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'result': result}), 200, header)

@app.route("/connection_list")
def connection_list():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }
    
    try:
        with open('./config/db_config.json', 'r', encoding='utf-8') as f:
            db_config = json.load(f)

        return make_response(jsonify({'db_config': list(db_config.values())}), 200, header)
    except:
        with open('./config/db_config.json', 'w', encoding='utf-8') as f:
            db_config = {}
            json.dump(db_config, f, ensure_ascii=False)
        
        return make_response(jsonify({'db_config': [{}]}), 200, header)


@app.route("/test_db_connection")
def test_db_connection():
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    try:
        with open('./config/db_config.json', 'r', encoding='utf-8') as f:
            data = json.load(f)

        server = data['server']
        if data['port'] != '':
            server += (',' + data['port'])
        database = data['database']
        uid = data['username']
        pwd = data['password']

        if data['driver'] == 'MSSQL':
            connect_str = 'DRIVER={ODBC Driver 17 for SQL Server}; SERVER='+server+';DATABASE='+database+';UID='+uid+';PWD='+pwd

        cnxn = pyodbc.connect(connect_str)
        cursor = cnxn.cursor()

        result = "連線成功"


        sql_query = """
            SELECT * FROM dbo.Customers
        """

        cursor.execute(sql_query)

        records = cursor.fetchall()

        for r in records:
            print(f"{r.CustomerId}\t{r.Name}\t{r.Location}\t{r.Email}")

    except Exception as e:
        result = "連線失敗"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'result': result}), 200, header)

# 登入登出
@app.route('/api/login', methods=['POST', 'OPTIONS'])
@cross_origin()
def login():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    with open('./user_database/users.json', 'r', encoding='utf-8') as f:
        users = json.load(f)

    req = request.get_json()

    username = req.get('username')
    password = req.get('password')

    if username in users and users[username]["password"]== password:

        with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
          tokens = json.load(f)
        
        token = create_access_token(identity=username)
        tokens[token] = username

        with open('./user_database/tokens.json', 'w', encoding='utf-8') as f:
          json.dump(tokens, f, ensure_ascii=False)

        return make_response(jsonify({'token': token, 'group': users[username]['group']}), 200, header)

    return make_response(jsonify({'msg': '帳號或密碼錯誤'}), 401, header)

@app.route('/api/logout', methods=['POST', 'OPTIONS'])
@cross_origin()
def logout():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    req = request.get_json()
    token = req.get('token')

    with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
          tokens = json.load(f)

    if token in tokens:
        tokens.pop(token)

    return make_response(jsonify({'result': '已登出'}), 200, header)

@app.route('/api/check_token', methods=['POST', 'OPTIONS'])
@cross_origin()
def check_token():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    req = request.get_json()
    token = req.get('token')
    try:
        with open('./user_database/tokens.json', 'r', encoding='utf-8') as f:
            tokens = json.load(f)
        
        if token in tokens:
            with open('./user_database/users.json', 'r', encoding='utf-8') as f:
                users = json.load(f)

            username = tokens[token]

            return make_response(jsonify({'result': '已登入', 'username': username, 'group': users[username]['group']}), 200, header)

    except Exception as e:
        print(e)

    return make_response(jsonify({'result': '請重新登入', 'username': ''}), 200, header)

@app.route('/api/reset', methods=['POST', 'OPTIONS'])
@cross_origin()
def reset():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    with open('./user_database/users.json', 'r', encoding='utf-8') as f:
        users = json.load(f)

    req = request.get_json()

    username = req.get('username')
    oldPWD= req.get('oldPWD')
    newPWD = req.get('newPWD')

    if username in users and users[username]["password"]== oldPWD:

        users[username]["password"] = newPWD

        with open('./user_database/users.json', 'w', encoding='utf-8') as f:
          json.dump(users, f, ensure_ascii=False)

        return make_response(jsonify({'msg': '重設成功'}), 200, header)

    return make_response(jsonify({'msg': '舊密碼錯誤'}), 401, header)

@app.route("/user_list")
def user_list():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    with open('./user_database/users_auth.json', 'r', encoding='utf-8') as f:
        users_auth = json.load(f)

    return make_response(jsonify({'users': list(users_auth.values())}), 200, header)

@app.route('/auth_update', methods=['POST', 'OPTIONS'])
@cross_origin()
def auth_update():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    req = request.get_json()
    username = req.get('username')
    databases = req.get('databases')

    try:
        with open('./user_database/users_auth.json', 'r', encoding='utf-8') as f:
            users_auth = json.load(f)

        users_auth[username]["databases"] = databases
        
        with open('./user_database/users_auth.json', 'w', encoding='utf-8') as f:
            json.dump(users_auth, f, ensure_ascii=False)
            

    except Exception as e:
        print(e)

    return make_response(jsonify({'result': '更新成功'}), 200, header)


@app.route('/api/protected', methods=['GET'])
@cross_origin()
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify(message=f'你好，{current_user}！這是受保護的數據。')

# 彙總
@app.route('/get_summary')
def get_summary():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    try:
        # result = Agent.SummaryFunc.query(user_input)
        start = time.time()
        # result = Agent.SummaryFunc.summary()
        result = Agent.SummaryFunc.sqlCommand
        end = time.time()

        print(f"\nTotal Summary time: {end - start}")

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'response': result}), 200, header)

# # RAG
# @app.route('/get_qa', methods=['POST', 'OPTIONS'])
# @cross_origin()
# def get_qa():
    
#     header={
#         'Content-Type': 'application/json',
#         'Access-Control-Allow-Origin': '*',
#         'Access-Control-Allow-Methods': 'POST'
#     }
#     data = request.get_json()
#     print(f'server receive data from User input: {data}')
#     user_input = data.get('inputText') #等同於 data['inputText']

#     try:
#         result = RetrievalQA.invoke(user_input)

#     except Exception as e:
#         result = "我不知道怎麼回答"
#         print(f'\n錯誤訊息: {e}')

#     return make_response(jsonify({'response': result}), 200, header)

# # 上傳檔案
# @app.route('/upload_doc', methods=['POST'])
# @cross_origin()
# def upload_documents():
#     responses = []
#     print(f'\nfile objects that I receive in this upload:{request.files}')
#     if 'file' not in request.files:
#         return jsonify({'message': 'No file part in the request.'}), 400

#     files = request.files.getlist('file')  # Get the list of files

#     for file in files:
#         print('\nthis file:', file)
#         if file.filename == '':
#             responses.append({'message': '''檔案不存在''', 'code': 400})
        
#         try:
#             saved_file_name = "./database/File/" + file.filename

#             if os.path.isfile(saved_file_name):
#                 responses.append({
#                     'message': f'{file.filename} 檔案已存在', 'code': 200
#                 })
#             else:    
#                 file.save(saved_file_name)
#                 RetrievalQA.process_and_store_documents([saved_file_name])
#                 responses.append({
#                     'message': f'{file.filename} 上傳成功', 'code': 200
#                 })
            
#         except Exception as e:
#             app.logger.debug('Debug message')
#             print(str(e))
#             responses.append({
#                     'message': f'{file.filename} 上傳失敗', 'code': 200
#                 })

#     return jsonify({'responses': responses}), 200

@app.after_request
def after_request(response):
    response.access_control_allow_origin = "*"
    return response

if __name__ == "__main__":
    app.run(debug=True, port=5001)