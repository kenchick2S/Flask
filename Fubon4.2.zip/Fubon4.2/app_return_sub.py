from flask import Flask, request, render_template, make_response, jsonify, send_file
from flask_cors import CORS, cross_origin
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import timedelta

from getCustomerDataset import  getCsvDataset
import time
import os
import shutil
import tempfile
import pandas as pd
import json
import math

import io
from urllib.parse import quote

import uuid
import hashlib

import pyodbc

from Langchain_Agent import SummaryFunc, RetrievalQA, llm, query_by_SQL, parse_question


# Global Variables: 儲存資料來渲染表格
Ai_response = ""

root = "./database"

# Flask App
app = Flask(__name__)

app.config['JWT_SECRET_KEY'] = 'your_secret_key'  # 更改為你的密鑰
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=1)
jwt = JWTManager(app)

app.config['JSON_SORT_KEYS'] = False
CORS(app)

# Function

def list_directory_contents(root_path = root, path_postfix="/"):
    try:
        path = root_path + path_postfix
        items = os.listdir(path)
        
        parent_folder_id = create_uuid_from_string(path)

        for item in items:
            item_path = os.path.join(path, item)

            item_id = create_uuid_from_string(str(item_path))

            if(item_id not in all_item_json["fileMap"][parent_folder_id]["childrenIds"]):
                all_item_json["fileMap"][parent_folder_id]["childrenIds"].append(item_id)

            if os.path.isfile(item_path): # file

                all_item_json["fileMap"][item_id] = {"id":item_id, "name": item, "parentId": parent_folder_id, "path": item_path.replace(root_path, '')}
            
            elif os.path.isdir(item_path): # folder

                all_item_json["fileMap"][item_id] = {"id":item_id, "name": item,"isDir": "true","childrenIds":[], "parentId": parent_folder_id, "path": item_path.replace(root_path, '')}
                

        return all_item_json

    except FileNotFoundError:
        print(f"The directory {path} does not exist.")
    except PermissionError:
        print(f"Permission denied for directory {path}.")
    except Exception as e:
        print(f"An error occurred: {e}")

    return None

def create_uuid_from_string(val: str):
    hex_string = hashlib.md5(val.encode("UTF-8")).hexdigest()
    return str(uuid.UUID(hex=hex_string))

rootFolderId = create_uuid_from_string(root + '/')
all_item_json = {"rootFolderId": rootFolderId,"fileMap":{rootFolderId:{"id":rootFolderId,"name":"database","isDir": "true","childrenIds":[], "path": "/"}}}

# Backend API

# 測試用
@app.route('/get_test', methods=['POST', 'OPTIONS'])
@cross_origin()
def test_input():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    sqlCommand = '''
        SELECT DISTINCT CN002, SUM(TA006) AS 總交易金額 FROM 客戶資料表 JOIN 交易資料表 ON CUS001 = CI004 WHERE YEAR(TD002) = 2023 AND AD003 LIKE '%台中市%' GROUP BY CN002
    '''
    SummaryFunc.sqlCommand = sqlCommand
    result = SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./database/Oracle", sqlCommand))

    return make_response(jsonify({'response': "測試", 'data': result.to_json(orient='records')}), 200, header)

@app.route('/get_keyword_test', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_keyword_test():

    global Ai_response

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    result = '測試' + "\n\n 請問以上是否正確? 正確，請回答'1'，不正確，請回答'2'。"

    data = request.get_json()
    SummaryFunc.Input_Question = data.get('inputText')

    return make_response(jsonify({'response': result, 'check': 'True'}), 200, header)

@app.route('/get_summary_test', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_summary_test():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    try:
        data = request.get_json()
        user_input = data.get('inputText')
        SummaryFunc.Input_Question = user_input
        with open(SummaryFunc.test_folder + SummaryFunc.test_jsonfile, 'r') as f:
            data = json.load(f)
            if user_input in data.keys():
                temp = pd.read_csv(SummaryFunc.test_folder + data[user_input], encoding='utf-8')
                SummaryFunc.store_dataset(temp, True)

                start = time.time()
                result = SummaryFunc.summary()
                end = time.time()

                print(f"\nTotal Summary time: {end - start}")
            else:
                result = "沒有這個查詢結果"

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'response': result}), 200, header)

# 查看指定資料夾底下的所有檔案

@app.route('/check_folder', methods=['POST', 'OPTIONS'])
@cross_origin()
def check_folder():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    data = request.get_json()
    subpath = data.get('subpath')
    result = list_directory_contents(path_postfix=subpath)
    if result is not None:
        return make_response(jsonify({"content": result}), 200, header)

    return make_response(jsonify({"content": []}), 404, header)

@app.route('/new_folder', methods=['POST', 'OPTIONS'])
@cross_origin()
def new_folder():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    
    try:
        result = "新增成功"
        data = request.get_json()
        folder_name = data.get('folderName')
        subpath = data.get('subpath')
        folder_path = os.path.join(root + subpath, folder_name)
        os.mkdir(folder_path)
        print(f"Directory '{folder_path}' created successfully.")
    except FileExistsError:
        print(f"Directory '{folder_path }' already exists.")
        result = "資料夾已存在"
    except OSError as e:
        print(f"Error creating directory '{folder_path }': {e}")
        result = "無法新增"

    return make_response(jsonify({'status': result}), 200, header)

# 上傳檔案到所在資料夾
@app.route('/upload_metadata', methods=['POST'])
@cross_origin()
def upload_metadata():
    messages = ""
    print(f'\nfile objects that I receive in this upload:{request.files}')
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in the request.'}), 400

    files = request.files.getlist('file')  # Get the list of files
    subpath = request.form.get('subpath')

    for file in files:
        print('\nthis file:', file)
        if file.filename == '':
            messages +=  "檔案不存在\n"
        
        try:
            saved_file_name = os.path.join(root + subpath, file.filename)

            if os.path.isfile(saved_file_name):
                messages += f'{file.filename} 檔案已存在\n'

            else:    
                file.save(saved_file_name)
                messages += f'{file.filename} 上傳成功\n'
            
        except Exception as e:
            app.logger.debug('Debug message')
            print(str(e))
            messages += f'{file.filename} 上傳失敗\n'

    return jsonify({'result': messages}), 200

# 刪除資料
@app.route('/delete_metadata', methods=['POST'])
@cross_origin()
def delete_metadata():

    result = ""
    data = request.get_json()
    selected_list = data.get('selected')
    for item in selected_list:
        try:
            if('isDir' in item):
                os.rmdir(root + item['path'])
            else:
                os.remove(root + item['path'])
            
            item_id = create_uuid_from_string(root + item['path'])
            parentId = all_item_json["fileMap"][item_id]['parentId']
            all_item_json["fileMap"][parentId]['childrenIds'].remove(item_id)
            del all_item_json["fileMap"][item_id]

            result += (f"{item['name']}: 刪除成功\n")

        except Exception as e:
            print(f"Error: {e}")
            if('isDir' in item):
                result += (f"{item['name']}: 資料夾必須為空\n")
            else:
                result += (f"{item['name']}: 刪除失敗\n")
    return jsonify({'result': result}), 200

# SQL
@app.route('/get_keyword', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_keyword():

    global Ai_response

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']
    try:
        SummaryFunc.Input_Question = user_input

        start = time.time()
        SummaryFunc.keyword = parse_question(user_input).replace("A.", "")
        end = time.time()

        print(f"\nTotal Query time: {end - start}")
        
        
        result = SummaryFunc.keyword + "\n\n 請問以上是否正確? 正確，請回答'1'，不正確，請回答'2'。"

        return make_response(jsonify({'response': result, 'check': 'True'}), 200, header)

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\n錯誤訊息: {e}')
    
    return make_response(jsonify({'response': result, 'check': 'False'}), 200, header)
    

@app.route("/get_query", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_query():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']

    if(user_input != '1'):

        result = "請重新詢問"
    else:
        try:
            Ai_response = query_by_SQL()
            result = "查詢成功"

        except Exception as e:
            result = f"無法查詢，以下是系統生成的SQL：\n{SummaryFunc.sqlCommand}\n資料庫來源：{SummaryFunc.database}"
            print(f'\n錯誤訊息: {e}')
    
    return make_response(jsonify({'response': result, 'check': 'False'}), 200, header)

@app.route("/get_keyword_and_query", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_keyword_and_query():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']
    SummaryFunc.Input_Question = user_input

    try:
        Ai_keyword = ""
        Ai_keyword = Agent_Executor.invoke({"input": user_input})['output'].replace("A.", "")

        print(Ai_keyword)
        Ai_query = query_by_SQL()

        if not isinstance(Ai_query, str):
            if (Ai_query is None or len(Ai_query) == 0):
                result = '資料不存在'

            result = SummaryFunc.sqlCommand
        else:
            result = Ai_query

        return make_response(jsonify({'keyword': Ai_keyword, 'query': result}), 200, header)

    except Exception as e:
        result = f"無法查詢，以下是系統生成的SQL：\n{SummaryFunc.sqlCommand}\n資料庫來源：{SummaryFunc.database}"
        print(f'\n錯誤訊息: {e}')
    
    return make_response(jsonify({'keyword': Ai_keyword, 'query': result}), 200, header)

@app.route("/get_direct_query", methods=['POST', 'OPTIONS'])
@cross_origin()
def get_direct_query():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')

    user_driver = data.get('driver')
    user_id = data.get('id')
    user_sql = data.get('sql-query')

    directory = './database/'

    try:
        SummaryFunc.selected_driver = user_driver
        SummaryFunc.selected_id = user_id

        SummaryFunc.sqlCommand = user_sql 
        SummaryFunc.Input_Question = "Test"
        SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql(directory + user_driver, user_sql), direct=True)
        result = "查詢成功"

    except Exception as e:
        result = "查詢失敗"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'result': result, "count": SummaryFunc.count}), 200, header)


# 表格資料回傳
@app.route("/table")
def table():
    id = int(request.args.get('id'))
    sub = request.args.get('sub')

    if id > SummaryFunc.count-1:
        id = SummaryFunc.count-1
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    if sub:
        sub = int(sub)
    else:
        sub = -1

    try:
        if SummaryFunc.datasets[id][sub].empty:
            print(SummaryFunc.datasets[id][sub])
            return make_response(jsonify([{"question":SummaryFunc.history[id], "data":[{"無欄位名稱": "無欄位資料"}], "count": SummaryFunc.count, "sql": SummaryFunc.sql_history[id]}]), 200, header)

        else:
            df = SummaryFunc.datasets[id][sub].copy(deep=True)
            for column in df.dtypes[df.dtypes == 'datetime64[ns]'].index:
                df[column] = df[column].apply(lambda x: x.strftime("%Y-%m-%d"))

            json_data = df.to_json(orient='records')
            parsed = json.loads(json_data)

            print(json_data)
            
            subquery_list = []
            page = math.ceil(id/5)
            for i in range((page-1)*5, page*5):
                try:
                    if len(SummaryFunc.sql_history[i]) > 1:
                        subquery_list.append(i) 
                except:
                    pass

            return make_response(jsonify([{"question":SummaryFunc.history[id], "data": json_data, "count": SummaryFunc.count, "sql": SummaryFunc.sql_history[id], "subquery_list": subquery_list, "driver": SummaryFunc.database_history[id][0], "database": SummaryFunc.database_history[id][1]}]), 200, header)

    except Exception as e:
        print(str(e)+"\n")

        return make_response(jsonify([{"question":"", "data":[{"": ""}], "count": SummaryFunc.count, "sql": [], "subquery_list": [], "driver": "", "database": ""}]), 200, header)


@app.route("/download")
def download():
    id = int(request.args.get('id'))

    id_name = id+1

    print(f"saved length: {len(SummaryFunc.datasets)}")
    print(f"id: {id}")
    
    header={
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET'
            }

    try:
        if SummaryFunc.datasets[id].empty:
            print(SummaryFunc.datasets[id])

            return make_response("無資料可下載", 404, header)

        else:
            header={
                'Content-Type': "text/csv",
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET',
                "Content-Disposition": "attachment; filename*=UTF-8''{utf_filename}".format(utf_filename=quote(f"第{id_name}個查詢結果.csv".encode('utf-8')))
            }

            df = SummaryFunc.datasets[id].copy(deep=True)
            for column in df.dtypes[df.dtypes == 'datetime64[ns]'].index:
                df[column] = df[column].apply(lambda x: x.strftime("%Y-%m-%d"))

            print("準備下載...")
            
            return make_response(df.to_csv(encoding='utf-8', index=False), 200, header)
            # buffer = io.BytesIO()
            # df.to_csv(buffer,encoding='utf-8')
            # buffer.seek(0)
            # return send_file(buffer,
            #      download_name="test.csv",
            #      mimetype='text/csv')

    except Exception as e:
        print(str(e)+"\n")
        return make_response("錯誤", 404, header)

# 聊天歷史紀錄
@app.route("/get_history_list")
def get_history_list():
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    with open('./chat_history/chat.json', 'r', encoding='utf-8') as f:
        data = json.load(f)

    return make_response(jsonify({'history_list': data["chat_history_list"][::-1]}), 200, header)

@app.route("/history")
def history():
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    id = int(request.args.get('id'))

    with open('./chat_history/chat.json', 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    return make_response(jsonify({'chat': data["chat"][id]}), 200, header)

@app.route("/save_history", methods=['POST', 'OPTIONS'])
@cross_origin()
def save_history():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    chatId = None

    try:
        if request.method == 'POST':
            req = request.get_json()

            with open('./chat_history/chat.json', 'r', encoding='utf-8') as f:
                data = json.load(f)

                print(req['chat'])

                if int(req['chatId']) == -1:
                    data['chat'].append(req['chat'])
                    chatId = len(data['chat'])-1
                    data['chat_history_list'].append({
                        "chat_title": req['chat'][1]['HumanInput'],
                        "chat_time": req['chat'][1]['HumanTime'],
                        "chat_id": chatId
                    })
                else:
                    chatId = int(req['chatId'])

                    data['chat'][chatId] = req['chat']

            with open('./chat_history/chat.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)

    except Exception as e:
        print(e)
        print("error!!!")
        chatId = -1
    
    return make_response(jsonify({'chatId': chatId}), 200, header)

# 連線設定
@app.route("/save_db_config", methods=['POST', 'OPTIONS'])
@cross_origin()
def save_db_config():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')

    try:
        with open('./config/db_config.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        result = "儲存成功"

    except Exception as e:
        result = "儲存失敗"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'result': result}), 200, header)

@app.route("/test_db_connection")
def test_db_connection():
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    try:
        with open('./config/db_config.json', 'r', encoding='utf-8') as f:
            data = json.load(f)

        server = data['server']
        if data['port'] != '':
            server += (',' + data['port'])
        database = data['database']
        uid = data['username']
        pwd = data['password']

        if data['driver'] == 'MSSQL':
            connect_str = 'DRIVER={ODBC Driver 17 for SQL Server}; SERVER='+server+';DATABASE='+database+';UID='+uid+';PWD='+pwd

        cnxn = pyodbc.connect(connect_str)
        cursor = cnxn.cursor()

        result = "連線成功"


        sql_query = """
            SELECT * FROM dbo.Customers
        """

        cursor.execute(sql_query)

        records = cursor.fetchall()

        for r in records:
            print(f"{r.CustomerId}\t{r.Name}\t{r.Location}\t{r.Email}")

    except Exception as e:
        result = "連線失敗"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'result': result}), 200, header)

# 登入登出
@app.route('/api/login', methods=['POST', 'OPTIONS'])
@cross_origin()
def login():

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    users = {
        "admin": "123",
        '魏琬瑜': '456'
    }

    data = request.get_json()
    print(data)

    username = data.get('username')
    password = data.get('password')

    if username in users and users[username] == password:
        
        token = create_access_token(identity=username)

        return make_response(jsonify({'token': token}), 200, header)

    return make_response(jsonify({'msg': '帳號或密碼錯誤'}), 401, header)

@app.route('/api/protected', methods=['GET'])
@cross_origin()
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify(message=f'你好，{current_user}！這是受保護的數據。')

# 彙總
@app.route('/get_summary')
def get_summary():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET'
    }

    try:
        # result = SummaryFunc.query(user_input)
        start = time.time()
        # result = SummaryFunc.summary()
        result = SummaryFunc.sqlCommand
        end = time.time()

        print(f"\nTotal Summary time: {end - start}")

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'response': result}), 200, header)

# RAG
@app.route('/get_qa', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_qa():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']

    try:
        result = RetrievalQA.invoke(user_input)

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\n錯誤訊息: {e}')

    return make_response(jsonify({'response': result}), 200, header)

# 上傳檔案
@app.route('/upload_doc', methods=['POST'])
@cross_origin()
def upload_documents():
    responses = []
    print(f'\nfile objects that I receive in this upload:{request.files}')
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in the request.'}), 400

    files = request.files.getlist('file')  # Get the list of files

    for file in files:
        print('\nthis file:', file)
        if file.filename == '':
            responses.append({'message': '''檔案不存在''', 'code': 400})
        
        try:
            saved_file_name = "./database/File/" + file.filename

            if os.path.isfile(saved_file_name):
                responses.append({
                    'message': f'{file.filename} 檔案已存在', 'code': 200
                })
            else:    
                file.save(saved_file_name)
                RetrievalQA.process_and_store_documents([saved_file_name])
                responses.append({
                    'message': f'{file.filename} 上傳成功', 'code': 200
                })
            
        except Exception as e:
            app.logger.debug('Debug message')
            print(str(e))
            responses.append({
                    'message': f'{file.filename} 上傳失敗', 'code': 200
                })

    return jsonify({'responses': responses}), 200

@app.after_request
def after_request(response):
    response.access_control_allow_origin = "*"
    return response

if __name__ == "__main__":
    app.run(debug=True, port=5001)