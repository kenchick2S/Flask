import React, { useEffect, useState } from 'react';
import './UserList.css'
import axios from 'axios';

// 假設這是我們的使用者資料
const initialUsers = [
   {username: '無資料', databases: '無資料' },
//   { id: 2, username: 'user2', databases: 'db2' },
//   { id: 3, username: 'user3', databases: 'db1, db3' },
];

const UserList = () => {
  const [users, setUsers] = useState(initialUsers);
  const [editingUser, setEditingUser] = useState(null);
  const [newDatabases, setNewDatabases] = useState('');

  const handleEdit = (user) => {
    setEditingUser(user);
    setNewDatabases(user.databases);
  };

  const handleSave = () => {
    const updatedUsers = users.map((user) =>
      user.username === editingUser.username ? { ...user, databases: newDatabases } : user
    );

    axios.post('http://localhost:5001/auth_update', {'username': editingUser.username, 'databases': newDatabases})
    .then(() => {
        setUsers(updatedUsers);
        setEditingUser(null);
    })
  };

  const handleCancel = () => {
    setEditingUser(null);
  };

  useEffect(() => {
    axios('http://localhost:5001/user_list')
    .then(function (response){
        setUsers(response.data.users);
    })
  }, [])

  return (
    <>
        <div className='userlist-container'>
        <h1>使用者權限清單</h1>
        <table>
            <thead>
            <tr>
                <th>序號</th>
                <th>使用者名稱</th>
                <th>可使用的資料表</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            {users.map((user, id) => (
                <tr key={id+1}>
                <td>{id+1}</td>
                <td>{user.username}</td>
                <td>{user.databases}</td>
                <td>
                    <button onClick={() => handleEdit(user)}>編輯</button>
                </td>
                </tr>
            ))}
            </tbody>
        </table>
        </div>
        {editingUser && (
            <div className="userlist-overlay" >
                <div className='userlist-update-container'>
                    <h2>{"編輯 "+editingUser.username+" 可使用的資料表"}</h2>
                    <textarea
                        rows={3}
                        value={newDatabases}
                        onChange={(e) => setNewDatabases(e.target.value)}
                    />
                    <div>
                        <button onClick={handleSave}>完成</button>
                        <button onClick={handleCancel}>取消</button>
                    </div>
                </div>
            </div>
        )}
    </>
  );
};

export default UserList;