import { useState } from 'react';

import './ApiList.css'
import { CopySVG } from './SVG';

export default function ApiList(){

    const server_url = 'http://localhost:5001/'
    const api_list = [
        {
            'api_name': 'get_keyword',
            'api_http': 'POST',
            'api_desc': '獲取關鍵字解析，給使用者確認是否正確。請將回答傳到get_query。',
            'api_url': server_url + 'get_keyword',
            'api_req': [{'parameter': 'inputText', 'type': 'String', 'desc': '輸入的字串'}],
            'api_res': [{'parameter': 'response', 'type': 'String', 'desc': '問題的關鍵字解析結果'}]
        },
        {
            'api_name': 'get_query',
            'api_http': 'POST',
            'api_desc': '透過系統生成 SQL 語句，並查詢。',
            'api_url': server_url + 'get_query',
            'api_req': [{'parameter': 'inputText', 'type': 'String', 'desc': '輸入的字串'}],
            'api_res': [{'parameter': 'response', 'type': 'String', 'desc': '查詢是否成功'}]
        },
        {
            'api_name': 'result',
            'api_http': 'GET',
            'api_desc': '獲取已查詢的數據結果。',
            'api_url': server_url + 'result?id=',
            'api_req': [{'parameter': 'id', 'type': 'Integer', 'desc': 'id < 0，回傳最新結果; id 為 0 時回傳第一個查詢結果; id 越大，結果越新'}],
            'api_res': [{'parameter': 'question', 'type': 'String', 'desc': '問題紀錄'},
                        {'parameter': 'data', 'type': 'JSON', 'desc': '查詢結果紀錄'},
                        {'parameter': 'count', 'type': 'Integer', 'desc': '查詢結果總數'},
                        {'parameter': 'sql', 'type': 'String', 'desc': '系統生成的SQL語句'},
                        {'parameter': 'driver', 'type': 'String', 'desc': '資料庫類型'},
                        {'parameter': 'database', 'type': 'String', 'desc': '資料庫名稱'},
                    ]
        },
        {
            'api_name': 'upload_metadata',
            'api_http': 'POST',
            'api_desc': '上傳 metadata。',
            'api_url': server_url + 'upload_metadata',
            'api_req': [{'parameter': 'files', 'type': 'file', 'desc': '欲上傳的檔案'}],
            'api_res': [{'parameter': 'result', 'type': 'String', 'desc': '檔案是否上傳成功'}]
        },
    ]

    const [showApi, setShowApi] = useState(null);

    const handleShow = (api) => {
        setShowApi(api);
    } 

    const handleCancel = () => {
        setShowApi(null);
    }

    return(
        <>
            <div className="apilist-container">
                <div>
                    <table>
                        <thead>
                            <tr>
                                <th>API名稱</th>
                                <th>HTTP類型</th>
                                <th>功能描述</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {api_list.map((api, id) => (
                                <tr key={'api-'+id}>
                                    <td>{api.api_name}</td>
                                    <td>{api.api_http}</td>
                                    <td>{api.api_desc}</td>
                                    <td>
                                        <button onClick={() => handleShow(api)}>查看</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            {showApi && (
                <div className="apilist-overlay" >
                    <div className='apilist-show-container'>
                        <div id='apilist-cancel-btn' role='button' onClick={handleCancel}>x</div>
                        <div>
                            <h3>{showApi.api_url}<div role="button" style={{display: "inline", paddingLeft: "10px", verticalAlign: "middle"}} onClick={() => {navigator.clipboard.writeText(showApi.api_url).then(function(){alert('複製成功')})}}><CopySVG /></div></h3>
                            <h4>請求參數</h4>
                            <table>
                                <thead>
                                    <tr>
                                        <th>參數名稱</th>
                                        <th>類型</th>
                                        <th>描述</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {showApi.api_req.map((req, id) => (
                                        <tr key={showApi.api_name+'-req-'+id}>
                                            <td>{req.parameter}</td>
                                            <td>{req.type}</td>
                                            <td><div>{req.desc}</div></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            <h4>返回參數</h4>
                            <table>
                                <thead>
                                    <tr>
                                        <th>參數名稱</th>
                                        <th>類型</th>
                                        <th>描述</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {showApi.api_res.map((res, id) => (
                                        <tr key={showApi.api_name+'-res-'+id}>
                                            <td>{res.parameter}</td>
                                            <td>{res.type}</td>
                                            <td><div>{res.desc}</div></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}
        </>
    )
}