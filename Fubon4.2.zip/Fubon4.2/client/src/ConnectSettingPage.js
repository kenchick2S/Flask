
import { useState, useEffect } from 'react';
import axios from 'axios';

import './SettingPage.css'

function ConnectSettingPage(){

    const [config, setConfig] = useState( [{}] );

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        axios.post('http://127.0.0.1:5001/save_db_config', data)
        .then(response => {

            console.log('成功:', response.data);

            axios('http://localhost:5001/connection_list')
            .then(function (response){
                setConfig(response.data.db_config);
            })

        })
        .catch(error => {

            console.error('錯誤:', error);
        });
    
    }

    const handleTest = () => {

        axios('http://127.0.0.1:5001/test_db_connection')
        .then(response => {

            alert(response.data.result);

        })
        .catch(error => {

            // console.error('錯誤:', error);
            alert(error);
        });
    
    }

    const handleEdit = (cg) => {
        document.getElementById('driver').value = cg.driver;
        document.getElementById('connection').value = cg.connection;
        document.getElementById('server').value = cg.server;
        document.getElementById('port').value = cg.port;
        document.getElementById('database').value = cg.database;
        document.getElementById('username').value = "";
        document.getElementById('password').value = "";
    };

    useEffect(() => {
        axios('http://localhost:5001/connection_list')
        .then(function (response){
            setConfig(response.data.db_config);
        })
      }, [])

    return(
        <>  
            <div className="setting-container">
                <div className='connection-container'>
                    <form className="form-container" onSubmit={handleSubmit}>
                        <div>
                            <label htmlFor="driver">資料庫類型:</label>
                            <select id="driver" name="driver">
                                <option value="Oracle">Oracle</option>
                                <option value="MSSQL">MSSQL</option>
                            </select>
                        </div>
                        <div className="setting-form">
                            <div>
                                <label for="connection">連線設定名稱:</label>
                                <input type="text" id="connection" name="connection" required />
                            </div>
                            <div>
                                <label for="server">伺服器名稱:</label>
                                <input type="text" id="server" name="server" placeholder='ex: 192.168.1.1' required />
                            </div>
                            <div>
                                <label for="port">連線埠 (Port):</label>
                                <input type="text" id="port" name="port" placeholder='ex: 1433' />
                            </div>
                            <div>
                                <label for="database">資料庫名稱:</label>
                                <input type="text" id="database" name="database" required />
                            </div>
                            <div>
                                <label for="username">使用者名稱:</label>
                                <input type="text" id="username" name="username" required />
                            </div>
                            <div>
                                <label for="password">密碼:</label>
                                <input type="password" id="password" name="password" required />
                            </div>
                        </div>
                        <div style={{marginLeft: 'auto', marginRight: 'auto', width: 'fit-content'}}>
                            <button type="submit" >儲存</button>
                            <button type="button" onClick={handleTest}>測試連線</button>
                        </div>
                    </form>
                    <div>
                        <table>
                            <thead>
                            <tr>
                                <th>序號</th>
                                <th>連線設定名稱</th>
                                <th>資料庫類型</th>
                                <th>伺服器名稱</th>
                                <th>連線埠 (Port)</th>
                                <th>資料庫名稱</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            {config.map((cg, id) => (
                                <tr key={id+1}>
                                <td>{id+1}</td>
                                <td>{cg.connection}</td>
                                <td>{cg.driver}</td>
                                <td>{cg.server}</td>
                                <td>{cg.port}</td>
                                <td>{cg.database}</td>
                                <td>
                                    <button onClick={() => handleEdit(cg)}>編輯</button>
                                </td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ConnectSettingPage;