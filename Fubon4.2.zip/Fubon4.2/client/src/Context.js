
import { createContext } from "react"

export const FunctionDialogContext = createContext({
    analysis_state: null,
    analysis_setter: null,
    query_state: null,
    query_setter: null
});

const NavBarContext = createContext({
    tab_setter: null,
    auth_setter: null,
    user_state: null,
    user_setter: null,
    resetPWD_setter: null,
    group_state: null,
});

const FolderContext = createContext({
    path_state: null,
    path_setter: null,
    get_folders: null
});

const TableContext = createContext({
    id_state: null,
    id_setter: null,
    chatId_state: null,
    username_state: null,
    qList_state: null,
    sqlList_state: null,
    dbList_state: null,
    dataList_state: null,
    dataList_setter: null,
});

const HistoryContext = createContext({
    message_state: null,
    message_setter: null,
    chatId_setter: null,
    keyword_setter: null,
    show_state: null,
    show_setter: null,
    id_setter: null,
    qList_setter: null,
    sqlList_setter: null,
    dbList_setter: null,
    dataList_setter: null,
});

export {NavBarContext, FolderContext, TableContext, HistoryContext};
