import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';

import './Table.css'
import { TableContext } from './Context';
import { LeftArrow, RightArrow } from './SVG';

function HtmlRenderer() {
  const [resultBtn, setResultBtn] = useState([]);
  const [rowsData, setRowsData] = useState([]);
  const [colsName, setColsName] = useState([]);
  const [question, setQuestion] = useState("");
  const [sqlCommand, setSqlCommand]  = useState("");
  const [database, setDatabase]  = useState(["", ""]);
  const [toggle, setToggle] = useState(true);
  const [queryResult, setQueryResult] = useState("")

  const context = useContext(TableContext);

  const generate_rowsData = (data) => {
      let tmp = [];
      Object.values(data).forEach((column) => tmp.push(<td>{column}</td>));
      return tmp;
  } 

  const textareaOnChange = (e) => {
    setSqlCommand(e.target.value);
  }

  function sort_func(e){
    try{
      let index = e.target.id;
      let type = document.querySelectorAll('tbody>tr')[0].children[index].innerText;
      let isNumber = /^\d+$/.test(type);

      e.target.children[0].className = e.target.children[0].className === 'asc' ? 'desc' : 'asc';
      let order = e.target.children[0].className;

      let tbody = document.querySelector('tbody');
      let trs = tbody.querySelectorAll('tr');
      let orderList;
      orderList = Array.prototype.slice.call(trs).sort(function (a, b) {
        a = a.querySelectorAll('td')[index].innerHTML;
        b = b.querySelectorAll('td')[index].innerHTML;
        if (isNumber) {
          if (order === 'asc') {
            return a - b;
          } else if (order === 'desc') {
            return b - a;
          }
        } else if (order === 'asc') {
          return a.localeCompare(b, 'zh');
        } else if (order === 'desc') {
          return b.localeCompare(a, 'zh');
        }
        return null;
      });
      Array.prototype.slice.call(orderList).forEach((orderItem) => {
        tbody.appendChild(orderItem);
      });
    } catch(error) {
      console.log('Error Sorting:', error);
    }
  }

  const sqlFormat = (sqlCommand) => {
    const keywords = ['FROM', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'GROUP BY', 'ORDER BY', 'FETCH'];

    
    try{
      sqlCommand = sqlCommand.replaceAll('\n', '');
      for(let keyword of keywords){
        sqlCommand = sqlCommand.replace(keyword, '\n'+keyword);
      }
      
      return sqlCommand;
    }
    catch{
      return ""
    }
    
  }

  const handleSubmit = (e) => {
    e.preventDefault(); 

    const formData = new FormData(e.target);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });

    // data['id'] = context.id_state;
    let id = context.id_state;

    console.log(`direct id ${id}`);

    data['driver'] = context.dbList_state[id]
    data['token'] = localStorage.getItem('token')

    // console.log(data);

    axios.post('http://127.0.0.1:5001/get_direct_query', data)
        .then(response => {

          let htmlData = response.data.data;
          context.dataList_setter([...context.dataList_state.slice(0, id), htmlData, ...context.dataList_state.slice(id)])

          if(htmlData !== ""){
            if(typeof(htmlData) === "string"){
              htmlData = JSON.parse(htmlData);
            }
      
            let tmp_rowsData = [];
            let tmp_colsName = [];
      
            for (let i=0; i < htmlData.length; i++) {
              tmp_rowsData.push(<tr>{generate_rowsData(htmlData[i])}</tr>);
            }
            Object.keys(htmlData[0]).forEach((col_name, index) => tmp_colsName.push(<th scope="col" id={index}>{col_name}<span className="asc"></span></th>));


            setColsName(tmp_colsName);
            setRowsData(tmp_rowsData);
          }
          setQueryResult(response.data.result);

        })
        .catch(error => {

            console.error('錯誤:', error);
        });
  };

  async function fetchHtmlData() {
    try {
      // const response = await axios.post( 'http://localhost:5001/result', {
      //   id: context.id_state,
      //   username: context.username_state,
      //   chatId: context.chatId_state
      // });
      let id = context.id_state
      if(id < 0){
        if(context.sqlList_state.length > 0){
          id = context.sqlList_state.length - 1;
        }
        else{
          id = 0;
        }
      }

      // let htmlData = response.data[0].data;
      // console.log(context.dataList_state);
      console.log(`id: ${id}`);

      let htmlData = context.dataList_state[id]
      if(typeof(htmlData) === "string"){
        htmlData = JSON.parse(htmlData);
      }

      let tmp_rowsData = [];
      let tmp_colsName = [];

      if(htmlData === undefined){
        htmlData = [{}];
      }

      for (let i=0; i < htmlData.length; i++) {
        tmp_rowsData.push(<tr>{generate_rowsData(htmlData[i])}</tr>);
      }
      Object.keys(htmlData[0]).forEach((col_name, index) => tmp_colsName.push(<th scope="col" id={index}>{col_name}<span className="asc"></span></th>));

      let rows = []
      let count = context.sqlList_state.length
      let page = 0;
      let displayNum = 5;
      
      if(context.id_state >= 0){
        page = Math.ceil((context.id_state+1)/displayNum);
      }
      else{
        page = Math.ceil((count)/displayNum);
      }

      if(page > 1){
          rows.push(<>
                      <div role='button' className='page-btn' onClick={() => context.id_setter((page-1)*5-1)}><LeftArrow /></div>
                    </>)
      }
      if(page > 0){
        for (let i=(page-1)*5; i < page*5; i++) {
            if(i < count){
              rows.push(<div>
                          <input id={"tab"+i} type="radio" name="tab" onChange={() => context.id_setter(i)} />
                          <label htmlFor={"tab"+i}>{i+1}</label>
                        </div>);
            }
        }
      }
      if(page*5 < count){
        if(count < (page+1)*5){
          rows.push(<>
                      <div role='button' className='page-btn' onClick={() => {context.id_setter(count-1)}}><RightArrow /></div>
                    </>)
        }
        else{
          rows.push(<>
            <div role='button' className='page-btn' onClick={() => {context.id_setter((page+1)*5-1)}}><RightArrow /></div>
          </>)
        }
      }
      
      // setSqlCommand(sqlFormat(response.data[0].sql));
      setSqlCommand(sqlFormat(context.sqlList_state[id]));
      setColsName(tmp_colsName);
      setRowsData(tmp_rowsData);
      setQuestion(context.qList_state[id]);
      setDatabase(context.dbList_state[id]);
      setResultBtn(rows);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  // 更新表格資料
  useEffect(() => {
    // 在 useEffect 中發送 HTTP 請求
    fetchHtmlData()
    // return(() => {
    //   for(let ele of document.getElementsByName("tab")){
    //     ele.checked = false;
    //   }
    // })
  }, [context.id_state, context.chatId_state]);

  useEffect(() => {
    if(context.chatId_state >= 0){
      setToggle(false);
    }
  }, [context.chatId_state])

  // 更新表頭的 EventListener，點擊表頭會排序
  useEffect(() => {
    let ths = document.querySelectorAll('th');
    ths.forEach((node) => {
      node.addEventListener('click', sort_func);
    });
    
    return () => {
      ths.forEach((node) => {
        node.removeEventListener('click', sort_func);
      });
    }

  }, [rowsData, toggle])

  useEffect(() => {
    let length = document.getElementsByName("tab").length;
    let tabs = document.getElementsByName("tab")
    console.log('length:' + length);
    if(length !== 0){
      tabs[length-1].defaultChecked = true;
    }

    return(() => {
      for(let ele of tabs){
        ele.removeAttribute('checked');
        ele.removeAttribute('defaultChecked');
      }
    })
  }, [resultBtn])

  useEffect(() => {
    document.getElementById('toggle1').defaultChecked = 'true';
  }, [toggle])

  return (

    <div className="table-container">
      <div className='toggle-container'>
        <input id='toggle1' type="radio" name='toggle' checked={toggle} onChange={() => setToggle(true) }/>
        <label htmlFor='toggle1'>表格</label>
        <input id='toggle2' type="radio" name='toggle' checked={!toggle} onChange={() => setToggle(false)}/>
        <label htmlFor='toggle2'>SQL</label>
      </div>
      <div className="tab_css">
        {resultBtn}
      </div>
      <div className='question-style'>{question}</div>
      { (toggle && question !== "") &&
        <>
          <a href={`http://localhost:5001/download?id=${context.id_state}`}>下載</a>
          <table id="table">
              <thead>
                  <tr>
                      {colsName}		
                  </tr>
              </thead>
              <tbody>
                {rowsData}
              </tbody>
          </table>
        </>
      }
      {(!toggle)&&
        <>
            {/* <div className='sql-container'>
              <div className='sql-style' style={{border: sqlCommand!=="" ? "#F0F0F0 0.5px solid" : ""}}>{sqlFormat(sqlCommand)}</div>
            </div> */}
            <form className='query-box-form' onSubmit={handleSubmit}>
              <div>
                {/* <label htmlFor="sql-query">自定義SQL查詢:</label> */}
                <div className='label-btn-between'>
                  <div>
                    <label htmlFor="driver">資料庫類型: {database[0]}</label>
                  </div>
                  <div>
                    <label htmlFor="database">資料庫名稱: {database[1]}</label>
                  </div>
                  <button type="submit" style={{display: 'inline-block', border: '1px solid #F0F0F0'}}>重新查詢</button>
                </div>
                <textarea id="sql-query" name="sql-query" rows={5} value={sqlCommand} onChange={textareaOnChange} placeholder="請輸入您的 SQL 查詢語句" ></textarea>
                <div>
                  <label>{queryResult}</label>
                </div>
              </div>
          </form>
        </>
      }
    </div>
  );
}


export default HtmlRenderer;