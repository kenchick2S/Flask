import React, { useEffect, useState } from 'react';
import axios from 'axios';

import './App.css';
import human_pic from './assets/human.jpg';
import ai_pic from './assets/ai.jpg';

import { ArrowSVG, DotsSVG, HistorySVG, NewChatSVG } from './SVG';

import {NavBarContext, TableContext, HistoryContext} from './Context';

import { NavBarLeft, NavBarTop } from './NavBar';
import { MutableFS } from './MutableFS';
import HtmlRenderer from './Table';

import History from './History';
import ConnectSettingPage from './ConnectSettingPage';
import CommonSettingPage from './CommonSettingPage';
import UserList from './UserList';
import ApiList from './ApiList';
import SpeechTool from './SpeechTool';

// Scroll bar 聊天內容增加就自動向下
// 新增聊天以及歷史紀錄

  

function App() {
	const [userInput, setUserInput] = useState('');
	const [messages, setMessages] = useState([
		{
			AiResponse: "您好，請問您要查詢什麼資料呢？",
			AiTime: "",
		}
	]);
	const [question, setQuestion] = useState('');
	const [keyword, setKeyword] = useState('');

	const [loading, setLoading] = useState(false);

	const [showTab, setTab] = useState([true, false]);

	const [id, setID] = useState(null);

	const [chatId, setChatId] = useState(-1);
	const [qList, setQList] = useState([]);
	const [sqlList, setSqlList] = useState([]);
	const [dbList, setDbList] = useState([["", ""]]);
	const [dataList, setDataList] = useState([]);
	

	const [menuShow, setMenuShow] = useState(false);
	const [historyShow, setHistoryShow] = useState(false);

	const [isAuthenticated, setIsAuthenticated] = useState(false);
	const [isResetPWD, setIsResetPWD] = useState(false);
	const [error, setError] = useState("");

	const [username, setUsername] = useState('尚未登入');
	const [group, setGroup] = useState('user');

	const saveHistory = (history) => {

		axios.post('http://localhost:5001/save_history', {
			'username': username,
			'chatId': chatId,
			'chat': history,
		})
		.then(function (response){
			setChatId(response.data.chatId);
		})
		.catch(function (err){
			console.log(err);
		})
	}

	const handleInputChange = (e) => {
			setUserInput(e.target.value);

			if(e.target.scrollHeight < 76){
				e.target.style.overflowY = "hidden";
				e.target.style.height = "auto";
				e.target.style.height = (e.target.scrollHeight) + "px";
			}
			else{
				e.target.style.height = "76px";
				e.target.style.overflowY = "auto";
			}
		};

	const setWaitingMsg = (waiting) => {

		setLoading(true);
		setUserInput('');
		let userInputTime = new Date();

		const loadingMessage = {
			HumanInput: userInput,
			AiResponse: waiting,
			HumanTime: userInputTime.toLocaleString(),
			AiTime: "",
		};
		// console.log('this loadingMessage:', loadingMessage);

		setMessages((prevMessages) => [...prevMessages, loadingMessage]);

		return userInputTime
	}

	const handleSendMessage = async (e) => {
		e.preventDefault();

		document.getElementById('content').style.height = "auto";
		
		if(keyword === ''){
			let userInputTime = setWaitingMsg("請等待回覆");

			axios.post('http://localhost:5001/get_keyword', {
				inputText : userInput,
			})
			.then(function (response){
				//console.log('status:', response.status)
				var status = response.status;
				var resp = status === 200 ? response.data.response : '暫時無法解析您的問題';

				setQuestion(userInput)
				setKeyword(resp);
				
				resp += "\n\n請問以上是否正確? 正確，請回答'1'，不正確，請回答'2'。";

				let AiResponseTime = new Date();

				const newMessage = {
					HumanInput: userInput,
					AiResponse: resp,
					HumanTime: userInputTime.toLocaleString(),
					AiTime: AiResponseTime.toLocaleString(),
				};
				setMessages((prevMessages) => [...prevMessages.slice(0, -1), newMessage]);
				
				saveHistory([...messages, newMessage]);
			})
			.catch(function (err){
				alert(`${err}`);
				setLoading(false);
				setKeyword('');
				let AiResponseTime = new Date();

				const newMessage = {
					HumanInput: userInput,
					AiResponse: "請重新嘗試",
					HumanTime: userInputTime.toLocaleString(),
					AiTime: AiResponseTime.toLocaleString(),
				};
				setMessages((prevMessages) => [...prevMessages.slice(0, -1), newMessage]);
				saveHistory([...messages, newMessage])
			})
			.finally(() => {
				setLoading(false);
			});
		}
		else{
			let userInputTime = setWaitingMsg("請等待資料查詢");

			if(userInput !== '1'){  // 準備 get_query，但不查詢 
				setUserInput('');
				setKeyword('');
	
				const loadingMessage = {
					HumanInput: userInput,
					AiResponse: "請重新詢問",
					HumanTime: userInputTime.toLocaleString(),
					AiTime: "",
				};
				setMessages((prevMessages) => [...prevMessages, loadingMessage]);
			}
			else{
				axios.post('http://localhost:5001/get_query', {
					username: username,
					inputText : question,
					keyword: keyword,
					token: localStorage.getItem('token'),
					chatId: chatId,
				})
				.then(function (response){
					//console.log('status:', response.status)
					var status = response.status;
					var resp = status === 200 ? response.data.response : '暫時無法解析您的問題';
				
					if(resp === "查詢成功"){
						setID(-1);
						setKeyword('');
					}
	
					let AiResponseTime = new Date();
	
					const newMessage = {
						HumanInput: userInput,
						AiResponse: resp,
						HumanTime: userInputTime.toLocaleString(),
						AiTime: AiResponseTime.toLocaleString(),
					};
					setMessages((prevMessages) => [...prevMessages.slice(0, -1), newMessage]);
					
					setQList([...qList, response.data.question])
					setSqlList([...sqlList, response.data.sql]);
					setDbList([...dbList, response.data.selected_db]);
					setDataList([...dataList, response.data.dataset]);
					
					saveHistory([...messages, newMessage]);
				})
				.catch(function (err){
					alert(`${err}`);
					setLoading(false);
					setKeyword('');
					let AiResponseTime = new Date();
	
					const newMessage = {
						HumanInput: userInput,
						AiResponse: "請重新嘗試",
						HumanTime: userInputTime.toLocaleString(),
						AiTime: AiResponseTime.toLocaleString(),
					};
					setMessages((prevMessages) => [...prevMessages.slice(0, -1), newMessage]);
					saveHistory([...messages, newMessage])
				})
				.finally(() => {
					setLoading(false);
				});
			}
		}

	};

	const handleLogin = async (e) => {
        e.preventDefault();

        axios.post('http://localhost:5001/api/login', {'username': e.target[0].value, 'password': e.target[1].value})
        .then((response) => {

            const data = response.data;
            localStorage.setItem('token', data.token);
			setIsAuthenticated(true);
			setUsername(e.target[0].value);
			setGroup(data.group);
            alert('登入成功！');
        })
        .catch(() => {
            alert('登入失敗，請檢查帳號密碼');
        })
    }

	const handleReset = async (e) => {
        e.preventDefault();

        axios.post('http://localhost:5001/api/reset', {'username': username, 'oldPWD': e.target[0].value, 'newPWD': e.target[1].value})
        .then(() => {
			setIsResetPWD(false);
            alert('重設成功！');
        })
        .catch(() => {
            alert('重設失敗，請檢查舊密碼是否正確');
        })
    }

	const CheckDiff = () => {
		const newPWD =  document.getElementById('newPWD').value;
		const comparePWD =  document.getElementById('comparePWD').value;

		if(newPWD !== comparePWD){
			setError("新密碼與確認密碼不相同");
		}
		else{
			setError("");
		}
	}

	useEffect(()=>{
		document.getElementsByClassName('chat')[0].scrollTop = document.getElementsByClassName('chat')[0].scrollHeight;
	}, [messages])

	useEffect(() => {
		if(chatId === -1){
			axios('http://localhost:5001/remove_history')
			.then(function (response){
				console.log(response.result)
				setID(-1);
			})
		}
	}, [chatId])

	useEffect(() => {
        const token = localStorage.getItem('token'); // call api 認證 token 有沒有過期，沒有的話回傳 username

		if(token){
			axios.post('http://localhost:5001/api/check_token', {'token': token})
			.then(function (response){
				if(response.data.username !== ""){
					setUsername(response.data.username);
					setIsAuthenticated(true); 
					setGroup(response.data.group);
				}
			})
		}

		return (() => {
				axios('http://localhost:5001/remove_history')
				.then(function (response){
					console.log(response.result)
				})
			})
    }, []);

	return (
		<>	{!isAuthenticated &&
				<>
					<div className="overlay" >
						<div className="login-container">
							<form onSubmit={handleLogin}>
								<h2>登入</h2>
								<div className='input-container'>
									<div>
										<label>帳號：</label>
										<input
											type="text"
											required
										/>
									</div>
									<div>
										<label>密碼：</label>
										<input
											type="password"
											required
										/>
									</div>
								</div>
								{/* {error && <p style={{ color: 'red' }}>{error}</p>} */}
								<div>
									<button type="submit">登入</button>
								</div>
							</form>
						</div>
					</div>
				</>
			}
			{isResetPWD &&
				<>
					<div className="overlay" >
						<div className="login-container">
							<form onSubmit={handleReset}>
								<h2>重設密碼</h2>
								<div className='input-container'>
									<div>
										<label>舊密碼：</label>
										<input
											type="password"
											required
										/>
									</div>
									<div>
										<label>新密碼：</label>
										<input
											type="password"
											required
											id="newPWD"
											onChange={() => {CheckDiff();}}
										/>
									</div>
									<div>
										<label>確認密碼：</label>
										<input
											type="password"
											required
											id="comparePWD"
											onChange={() => {CheckDiff();}}
										/>
									</div>
								</div>
								{error && <p style={{ color: 'red' }}>{error}</p>}
								<div>
									<button type="submit">確認</button>
									<button onClick={() => {setIsResetPWD(false);}}>取消</button>
								</div>
							</form>
						</div>
					</div>
				</>	
			}
			<div className='bg-container'>
				<NavBarContext.Provider value={{
						tab_setter: setTab,
						auth_setter: setIsAuthenticated,
						user_state: username,
						user_setter: setUsername,
						resetPWD_setter: setIsResetPWD,
					}}>
					<NavBarTop/>
				</NavBarContext.Provider>
				<div className='bottom-container'>
					<NavBarContext.Provider value={{
						tab_setter: setTab,
						auth_setter: setIsAuthenticated,
						user_state: username,
						user_setter: setUsername,
						group_state: group
					}}>
						<NavBarLeft/>
					</NavBarContext.Provider>

					{showTab[0] && 
					<>
						<TableContext.Provider value={{
							id_state: id,
							id_setter: setID,
							chatId_state: chatId,
							username_state: username,
							qList_state: qList, 
							sqlList_state: sqlList,
							dbList_state: dbList,
							dataList_state: dataList,
							dataList_setter: setDataList,
						}}>
							<HtmlRenderer/>
						</TableContext.Provider>
						<div className="chatbox">
							<div className='menu-btn' role='button' onClick={()=>{setMenuShow(!menuShow)}}>
								<DotsSVG />	
								{menuShow &&
									<div className='menu-list'>
										<div className='menu-func-btn' role='button' onClick={() => {setChatId(-1); setMessages([{AiResponse: "您好，請問您要查詢什麼資料呢？", AiTime: "",}]); setKeyword('');}}>
											<NewChatSVG /> <span>新增聊天</span>
										</div>
										<div className='menu-func-btn' role='button' onClick={() => {setHistoryShow(true);}}>
											<HistorySVG /> <span>聊天歷史紀錄</span>
										</div>
									</div>}
							</div> 
							{historyShow &&
								<HistoryContext.Provider value={{
												message_state: messages,
												message_setter: setMessages,
												chatId_setter: setChatId,
												keyword_setter: setKeyword,
												show_state: historyShow,
												show_setter: setHistoryShow,
												id_setter: setID,
												qList_setter: setQList,
												sqlList_setter: setSqlList,
												dbList_setter: setDbList,
												dataList_setter: setDataList,
											}}>
									<History />
								</HistoryContext.Provider>
							}
							<div className="chat scrollbar">
								<div className="chat-title">
									聊天室
								</div>
								<div>
									{messages.map((message, index) => (
									<div key={index}>
										{message.HumanInput && 
											<>
											<div className="humanTime">{message.HumanTime}</div>
											<div className="dialog human">
												<div style={{ whiteSpace: 'pre-wrap' }} className="human-box">
													{message.HumanInput}
												</div>
												<img alt="" className="img-profile" 
													src={human_pic} 
												/>
											</div>
											</>
										}
										<div className="AiTime">{message.AiTime}</div>
										<div className="dialog ai">
											<img alt="" className="img-profile" 
												src={ai_pic} 
											/>
											<div style={{ whiteSpace: 'pre-wrap' }} className="ai-box">
												<span>{message.AiResponse}</span>{loading && (message.AiResponse.includes("請等待")) && <span className="dot"></span>}
											</div>
										</div>
									</div>))}
								</div>
							</div>
							<form 
								className="inputbox" 
								onSubmit={handleSendMessage}
							>	
								<textarea
										className="msgbox"
										id="content"
										placeholder="Message"
										type="text"
										value={userInput}
										onChange={handleInputChange}

										rows={"1"}
								/>
								<button
									className= 'btn-send'
									type="submit"
									disabled = {loading}
								>
									<span>Send</span>
									<ArrowSVG/>
								</button>
							</form>
						</div>
					</>}
					{showTab[1] && <MutableFS/>}
					{showTab[2] && <CommonSettingPage/>}
					{showTab[3] && <ConnectSettingPage/>}
					{showTab[4] && <UserList/>}
					{showTab[5] && <ApiList/>}
					{showTab[6] && <SpeechTool/>}
				</div>
			</div>
		</>
	);
}

export default App;